self.options = {
    "domain": "5gvci.com",
    "zoneId": 11063426
}
self.lary = ""
importScripts('https://5gvci.com/act/files/service-worker.min.js?r=sw')
